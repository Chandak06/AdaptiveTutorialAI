from __future__ import annotations

import json
import re
from typing import Any


class JSONParseError(ValueError):
    pass


def extract_json_object(text: str) -> str:
    if not isinstance(text, str):
        raise JSONParseError("LLM output is not text.")

    fenced_match = re.search(
        r"```(?:json)?\s*(\{.*?\})\s*```",
        text,
        re.DOTALL,
    )

    if fenced_match:
        return fenced_match.group(1)

    start = text.find("{")

    if start == -1:
        raise JSONParseError("No JSON object found.")

    depth = 0
    in_string = False
    escaping = False

    for index in range(start, len(text)):
        char = text[index]

        if escaping:
            escaping = False
            continue

        if char == "\\":
            escaping = True
            continue

        if char == '"':
            in_string = not in_string
            continue

        if in_string:
            continue

        if char == "{":
            depth += 1

        elif char == "}":
            depth -= 1

            if depth == 0:
                return text[start:index + 1]

    raise JSONParseError("Unbalanced JSON object.")


def parse_json_object(text: str) -> dict[str, Any]:
    candidate = extract_json_object(text)

    try:
        payload = json.loads(candidate)

    except json.JSONDecodeError as exc:
        raise JSONParseError(
            f"Invalid JSON: {exc}"
        ) from exc

    if not isinstance(payload, dict):
        raise JSONParseError(
            "Top-level JSON must be an object."
        )

    return payload