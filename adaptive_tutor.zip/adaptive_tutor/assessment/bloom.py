BLOOM_KEYWORDS = {
    "remember": [
        "define",
        "list",
        "identify",
        "name"
    ],
    "understand": [
        "explain",
        "describe",
        "summarize"
    ],
    "apply": [
        "solve",
        "implement",
        "use"
    ],
    "analyze": [
        "compare",
        "differentiate",
        "analyze"
    ],
    "evaluate": [
        "justify",
        "evaluate",
        "critique"
    ],
    "create": [
        "design",
        "develop",
        "create"
    ]
}


def classify_bloom_level(question: str):
    q = question.lower()

    for level, words in BLOOM_KEYWORDS.items():
        for word in words:
            if word in q:
                return level.title()

    return "Understand"